const allSnapshots = [];
